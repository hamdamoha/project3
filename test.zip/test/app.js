const url = "http://127.0.0.1:5502/conversion.json"

// Use D3 to select the dropdown menu
let dropdownMenu = d3.select("#selDataset");

// get the Pokemon name to populate dropdown
d3.json(url).then((data) => {
    let pokemon = (data[i]["Pokemon name"]);
    pokemon.forEach((id)=> {
        dropdownMenu
            .append("Pokemon name")
            .attr("value", id)
            .text(id);
        
    });
    
});